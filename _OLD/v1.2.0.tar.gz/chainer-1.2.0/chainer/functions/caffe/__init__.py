from chainer.functions.caffe import caffe_function


CaffeFunction = caffe_function.CaffeFunction
