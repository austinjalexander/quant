--------------------
Core functionalities
--------------------

.. currentmodule:: chainer
.. toctree::
   :maxdepth: 1

   core/variable
   core/function
   core/function_set
   core/optimizer
