FunctionSet
-----------

.. currentmodule:: chainer
.. autoclass:: FunctionSet
   :members:
