Optimizer
---------

.. currentmodule:: chainer
.. autoclass:: Optimizer
   :members:
