************************
Chainer Reference Manual
************************

.. module:: chainer

.. toctree::
   :maxdepth: 2

   core
   util
   check
   functions
   optimizers
   caffe
   graph
