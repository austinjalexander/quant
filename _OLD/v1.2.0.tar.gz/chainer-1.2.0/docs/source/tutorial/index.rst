Chainer Tutorial
================

.. toctree::
   :maxdepth: 1

   basic
   recurrentnet
   gpu
   function
   type_check
